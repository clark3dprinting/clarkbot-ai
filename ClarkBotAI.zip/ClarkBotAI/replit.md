# ClarkBot - Advanced AI Assistant

## Overview

ClarkBot is an advanced AI assistant web application with voice recognition, image analysis, and intelligent conversation capabilities. The project features a sci-fi inspired dark mode interface with futuristic design elements, including neon blue accents, animated voice waves, and a glowing avatar. Built as a full-stack TypeScript application, it uses React for the frontend with a modern component architecture and Express for the backend API.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- React 18 with TypeScript as the primary UI framework
- Vite as the build tool and development server
- Client-side routing using Wouter (lightweight router)
- CSS handled via Tailwind CSS with custom theming

**Component Strategy**
- Component library based on shadcn/ui (Radix UI primitives)
- Custom components for AI-specific features (Avatar, VoiceWaves, ChatMessage, etc.)
- All components built with TypeScript and follow a compositional pattern
- Design system uses "New York" style variant from shadcn/ui

**State Management**
- TanStack Query (React Query) for server state and API interactions
- Local React state (useState) for UI-specific state
- No global state management library (Redux/Zustand) currently implemented

**Styling Approach**
- Tailwind CSS with custom configuration and CSS variables
- Dark mode as the primary theme with sci-fi aesthetic
- Custom fonts: Orbitron (headers/logo), Rajdhani (UI elements), Inter (body text)
- Custom animations for voice waves, glowing effects, and slide transitions
- Design tokens defined in CSS variables for colors, spacing, and elevation

### Backend Architecture

**Server Framework**
- Express.js for HTTP server and API routing
- TypeScript throughout the backend
- Development/production mode handling with environment-based configuration

**Development Setup**
- Vite middleware integration for hot module replacement in development
- Custom logging middleware for API request tracking
- Error handling middleware for consistent error responses

**API Design**
- RESTful API pattern with `/api` prefix for all routes
- Routes defined in `server/routes.ts` (currently minimal implementation)
- Storage abstraction layer through `IStorage` interface

### Data Storage Solutions

**Database ORM**
- Drizzle ORM for type-safe database operations
- PostgreSQL as the target database (via Neon serverless driver)
- Schema-first approach with TypeScript inference

**Current Schema**
- Users table with id, username, and password fields
- UUID-based primary keys with PostgreSQL's `gen_random_uuid()`
- Zod validation schemas derived from Drizzle schemas

**Storage Abstraction**
- `IStorage` interface defining CRUD operations
- In-memory implementation (`MemStorage`) for development/testing
- Designed to be swapped with database-backed implementation

**Migration Strategy**
- Drizzle Kit for schema migrations
- Migrations stored in `/migrations` directory
- Push-based deployment via `db:push` script

### Authentication & Authorization

**Current State**
- User schema exists with username/password fields
- No authentication middleware currently implemented
- No session management or JWT implementation present

**Design Considerations**
- Schema supports basic username/password authentication
- Session storage could use `connect-pg-simple` (already in dependencies)
- Password hashing would need to be implemented (no bcrypt/argon2 currently)

### External Dependencies

**UI Component Libraries**
- Radix UI primitives for accessible, unstyled components
- shadcn/ui component patterns and styling conventions
- Lucide React for iconography

**Form Handling**
- React Hook Form for form state management
- Hookform Resolvers for validation integration
- Zod for schema validation

**Database & Data Management**
- @neondatabase/serverless for PostgreSQL connectivity
- Drizzle ORM for queries and migrations
- date-fns for date manipulation

**Development Tools**
- Replit-specific plugins for development experience
- TypeScript for type safety
- ESBuild for production bundling

**Potential Integrations (Not Yet Implemented)**
- Voice recognition API (Web Speech API or external service)
- Image analysis API (OpenAI Vision, Google Cloud Vision, etc.)
- AI conversation API (OpenAI, Anthropic, etc.)

### Deployment Considerations

**Build Process**
- Frontend: Vite builds to `dist/public`
- Backend: ESBuild bundles to `dist/index.js`
- Single production artifact with static file serving

**Environment Requirements**
- DATABASE_URL environment variable required
- NODE_ENV for development/production switching
- Replit-specific environment variables for development features