import Avatar from '../Avatar';

export default function AvatarExample() {
  return <Avatar isActive={false} isProcessing={false} size="lg" />;
}
